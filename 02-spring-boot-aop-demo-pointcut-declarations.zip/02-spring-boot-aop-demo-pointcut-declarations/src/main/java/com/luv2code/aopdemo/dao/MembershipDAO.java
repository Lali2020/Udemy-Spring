package com.luv2code.aopdemo.dao;

public interface MembershipDAO {
    boolean addSillyMember();

    void goToSleep();
}
